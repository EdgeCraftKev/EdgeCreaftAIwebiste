# EdgeCraft AI Website

Professional website for EdgeCraft AI and CollabMe, featuring automated deployment to Hostinger.

## Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## Deployment

This project automatically deploys to Hostinger using webhooks when you push to the main branch.

### Setup Auto-Deployment
1. Follow instructions in `HOSTINGER_WEBHOOK_SETUP.md`
2. Setup the GitHub webhook (one-time setup)
3. Push changes and watch them go live automatically!

### Manual Deployment
```bash
npm run build:hostinger
# Upload dist/ contents to Hostinger public_html/
```

## Features

- ⚡ **Vite + React + TypeScript** - Modern development stack
- 🎨 **Tailwind CSS** - Beautiful, responsive design
- 🚀 **Automated Deployment** - Push to deploy via GitHub Actions
- 🔒 **Security Optimized** - .htaccess with security headers
- 📱 **Mobile First** - Fully responsive design
- ⚡ **Performance Optimized** - GZIP compression, caching, minification

## Project Structure

```
src/
  components/     # Reusable React components
  App.tsx        # Main application component
  main.tsx       # Application entry point
public/          # Static assets (images, logos, etc.)
dist/           # Production build output
```

## Technologies Used

- React 18 with TypeScript
- Tailwind CSS for styling
- Vite for blazing fast development
- Lucide React for beautiful icons
- GitHub Actions for CI/CD
- Hostinger for hosting