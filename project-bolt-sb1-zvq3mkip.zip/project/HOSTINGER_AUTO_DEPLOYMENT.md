# Hostinger FTP Auto-Deployment Setup (Legacy)

⚠️ **Note**: This is the legacy FTP deployment method. We now use Hostinger's webhook deployment for better performance. See `HOSTINGER_WEBHOOK_SETUP.md` for the current method.

This project was previously configured to automatically deploy to Hostinger via FTP whenever you push changes to the main/master branch.

## Setup Instructions

### 1. Get Your Hostinger FTP Credentials
1. Log into your Hostinger control panel
2. Go to **File Manager** or **FTP Accounts**
3. Note down:
   - **FTP Server**: Usually `ftp.yourdomain.com` or provided by Hostinger
   - **FTP Username**: Your main FTP username or create a new one
   - **FTP Password**: Your FTP password

### 2. Add Secrets to Your GitHub Repository
1. Go to your GitHub repository
2. Click **Settings** → **Secrets and variables** → **Actions**
3. Click **New repository secret** and add these three secrets:

   - **Name**: `HOSTINGER_FTP_SERVER`
     - **Value**: Your FTP server (e.g., `ftp.yourdomain.com`)
   
   - **Name**: `HOSTINGER_FTP_USERNAME`
     - **Value**: Your FTP username
   
   - **Name**: `HOSTINGER_FTP_PASSWORD`
     - **Value**: Your FTP password

### 3. How It Works
- **Automatic Deployment**: Every time you push to main/master branch
- **Build Process**: Runs `npm run build` to create optimized files
- **File Upload**: Uploads all `dist/` contents to your `public_html/` directory
- **Clean Deployment**: Only uploads production files (excludes node_modules, .git, etc.)

### 4. Deployment Process
```bash
# Make your changes locally
git add .
git commit -m "Update website content"
git push origin main

# GitHub Actions will automatically:
# 1. Build the project
# 2. Upload to Hostinger
# 3. Your live site updates within 2-3 minutes
```

### 5. Monitor Deployments
- Go to your GitHub repository → **Actions** tab
- See real-time deployment status
- View logs if any issues occur

### 6. Manual Deployment (Backup Method)
If you need to deploy manually:
```bash
npm run build:hostinger
# Then upload dist/ contents via Hostinger File Manager
```

## Security Notes
- FTP credentials are stored securely in GitHub Secrets
- Only production files are deployed
- No sensitive information is exposed in the repository

## Troubleshooting

### Deployment Fails
1. Check GitHub Actions logs for specific errors
2. Verify FTP credentials in repository secrets
3. Ensure Hostinger FTP service is active

### Site Not Updating
1. Clear browser cache
2. Check if FTP uploaded to correct directory
3. Verify file permissions on Hostinger

### First-Time Setup
The initial deployment might take longer. Subsequent updates are much faster.

## Benefits of This Setup
- ✅ **Zero Downtime**: Seamless updates
- ✅ **Automatic**: No manual file uploads needed  
- ✅ **Fast**: Updates live in 2-3 minutes
- ✅ **Reliable**: Built-in error handling and retries
- ✅ **Secure**: Encrypted credential storage