# Hostinger Webhook Auto-Deployment Setup

This project uses Hostinger's native webhook deployment for seamless updates from GitHub to your live website.

## 🚀 **How It Works**
1. **Push to GitHub** → GitHub builds your project → **Hostinger automatically deploys**
2. **Zero configuration needed** on Hostinger's end - it's all handled by their webhook system
3. **Faster than FTP** - Direct integration between GitHub and Hostinger

## 📋 **One-Time Setup Instructions**

### **Important: Repository Structure**
Hostinger webhook deployment requires `index.html` to be in the **root directory** of your repository. Our GitHub Actions workflow automatically handles this by:
1. Building the project (creates `dist/` folder)
2. Moving all built files from `dist/` to the root directory
3. Pushing the built files back to the repository
4. Triggering the Hostinger webhook

### **Step 1: Setup GitHub Webhook**
1. Go to your GitHub repository
2. Navigate to: **Settings** → **Webhooks** → **Add webhook**
   - Or use this direct link: https://github.com/EdgeCraftKev/EdgeCreaftAIwebiste/settings/hooks/new

3. **Configure the webhook:**
   - **Payload URL**: `https://webhooks.hostinger.com/deploy/9029aa1382808104d7574a7449adf1f1`
   - **Content type**: `application/json`
   - **Which events**: Select "Just the push event"
   - **Active**: ✅ Check this box
   - Click **Add webhook**

### **Step 2: Test the Deployment**
```bash
# Make a small change, then:
git add .
git commit -m "Test Hostinger webhook deployment"
git push origin main
```

### **Step 3: Monitor Deployment**
- **GitHub**: Go to Actions tab to see build status
- **Hostinger**: Check your hosting panel for deployment logs
- **Live Site**: Changes should appear in 2-3 minutes

## ✅ **Deployment Workflow**
```
Your Changes → Git Push → GitHub Actions Build → Hostinger Webhook → Live Site Updated
```

## 🔧 **Webhook Details**
- **Webhook URL**: `https://webhooks.hostinger.com/deploy/9029aa1382808104d7574a7449adf1f1`
- **Trigger**: Every push to main/master branch
- **Build Process**: GitHub Actions creates optimized production files
- **Deployment**: Hostinger automatically pulls and deploys the changes

## 🛠️ **Troubleshooting**

### **Deployment Not Triggering**
1. Check webhook is properly configured in GitHub
2. Verify webhook URL is correct
3. Ensure you're pushing to the correct branch (main/master)

### **Build Fails**
1. Check GitHub Actions logs for errors
2. Ensure all dependencies are listed in package.json
3. Test build locally: `npm run build`

### **Site Not Updating**
1. Clear browser cache
2. Check Hostinger deployment logs
3. Verify webhook received the payload

## 🎯 **Benefits of This Setup**
- ✅ **Native Integration** - Built specifically for Hostinger
- ✅ **Faster Deployment** - No FTP upload delays
- ✅ **More Reliable** - Direct webhook communication
- ✅ **Automatic Builds** - GitHub handles the build process
- ✅ **Real-time Status** - See deployment status in both platforms

## 🔒 **Security**
- Webhook URL is specific to your Hostinger account
- No credentials needed in GitHub repository
- Secure HTTPS communication between GitHub and Hostinger

This setup provides professional-grade deployment automation with minimal configuration!